const mongoose = require("mongoose");

const appointmentSchema = new mongoose.Schema({
  docid: {
    type: String,
    required: true,
  },
  testid: {
    type: String,
    required: true,
  },

  patient_email: {
    type: String,
    required: true,
  },
  patient_name: {
    type: String,
    required: true,
  },
  patient_age: {
    type: String,
    required: true,
  },
  patient_dob: {
    type: String,
    required: true,
  },
  patient_gender: {
    type: String,
    required: true,
  },
  questions: [
    {
      question: { type: String, required: true },
      answer: { type: String, required: true },
    },
  ],
  date: {
    type: Date,
    default: Date.now,
  },
  result: { type: String, required: true },
  confirmAppointment: { type: Boolean, default: false, required: true },
});


const Appointment = mongoose.model("Appointment", appointmentSchema);

module.exports = Appointment;